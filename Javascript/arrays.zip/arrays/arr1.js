let size=['s','m','l','xl'];
console.log(size[0]);
console.log(size[1]);
console.log(size[2]);
console.log(size[3]);
console.log(size[4]);