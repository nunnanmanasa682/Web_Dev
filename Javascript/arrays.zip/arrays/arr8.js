let names=['siri','raghu','shanu','mahi'];
for(name of names){
    console.log(name);
}