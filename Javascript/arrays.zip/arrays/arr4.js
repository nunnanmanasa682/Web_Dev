let a=[];
console.log(a.length);
