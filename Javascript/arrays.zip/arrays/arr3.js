let a=[];
let b=[10,20,30];
let c=[10,20,30,10,10,10,20];
let d=[10,'manasa','pooja',true,false,null,undefined,[],{},];
console.log(a);
console.log(b);
    console.log(c);
        console.log(d);