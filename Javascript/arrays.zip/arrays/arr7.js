let names=['siri','raghu','shanu','mahi'];
let i=0;
do{
    console.log(names[i]);
    i++;
}while(i<=3)