let names=['manasa','pooja','manas','divi','vasu','akhi'];
for(let i=0;i<=5;i++){
    console.log(names[i]);
}