let names=['rahul','priyanka','indira','rajiv','modi'];
let i=0;
while(i<=4){
    console.log(names[i]);
    i++;
}