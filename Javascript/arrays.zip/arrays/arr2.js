let a=[1,2];
a='rahul';
console.log(a);