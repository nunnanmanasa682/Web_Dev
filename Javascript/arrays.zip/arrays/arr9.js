let a=[]
let b=[10,20,30];
 if(b.length){
    console.log("given array is not empty");
}
    else
    {
        console.log("array is  empty");
    }
