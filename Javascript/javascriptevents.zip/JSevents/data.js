function writeData(){
    document.getElementById('abc').innerHTML="good morning"
    
}