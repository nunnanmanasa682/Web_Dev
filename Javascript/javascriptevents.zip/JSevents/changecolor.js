function changecolor(){
    document.setElementById(abc),
    style.background="blue";
}