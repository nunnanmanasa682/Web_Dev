function changeimage(){
    document.getElementById.style.slide2.jpg

}