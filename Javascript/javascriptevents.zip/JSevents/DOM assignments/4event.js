function changecolor3(){
    document.getElementById('abc').style.background="blue"
 }