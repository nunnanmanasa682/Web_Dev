function changecolor1(){
    document.getElementById('abc').style.background="blue"
}