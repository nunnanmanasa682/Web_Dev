function changecolor(){
   document.getElementById('abc').style.background="red"
}