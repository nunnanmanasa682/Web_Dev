function changecolor2(){
    document.getElementById('abc').style.background="aqua"
 }