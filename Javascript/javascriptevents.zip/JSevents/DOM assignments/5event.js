function changecolor4(){
    document.getElementById('abc').style.background="aqua"
 }