function wish1(){
    alert("hello manasa");
}