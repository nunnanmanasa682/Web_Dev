function wish(){
alert('gm');
}